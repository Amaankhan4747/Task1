import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import PatientList from './components/PatientList';
import AddPatient from './components/AddPatientFrom';
import PatientDetails from './components/PatientDetails';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<PatientList />} />
        <Route path="/add-patient" element={<AddPatient />} />
        <Route path="/patient-details" element={<PatientDetails />} />
      </Routes>
    </Router>
  );
}

export default App;
