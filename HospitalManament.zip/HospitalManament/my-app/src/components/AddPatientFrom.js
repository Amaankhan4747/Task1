import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AddPatient.css'
import axios from 'axios';
import {Link} from 'react-router-dom'
function AddPatient() {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:3001/add', {
        name,
        age,
        bedAllotted: true,
      });

      if (response.status === 201) {
        // const patientId = response.data._id; // Get the newly added patient's ID
        navigate(`/patient-details`); // Redirect to the patient details page with ID
      }
    } catch (error) {
      console.error('Error adding patient:', error);
      if (error.response && error.response.data) {
        console.error('Server error:', error.response.data.message);
      } else {
        console.error('An unknown error occurred');
      }
    }
  };

  return (

            
    
   <div>
      <Link style={{textAlign:'center'}} to='/patient-details' >Patients List</Link>
   
      <h1 style={{textAlign:'center'}}>Add New Patient</h1>
      

      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label>Age:</label>
          <input type="number" value={age} onChange={(e) => setAge(e.target.value)} required />
        </div>
        <button type="submit">Add Patient</button>
      </form>
    </div>
  );
}

export default AddPatient;
