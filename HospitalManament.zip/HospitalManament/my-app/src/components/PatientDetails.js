import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

function PatientDetails() {
  const { id } = useParams(); // Get the patient ID from the URL
  const [patient, setPatient] = useState(null);

  useEffect(() => {
    const fetchPatient = async () => {
      try {
        const response = await axios.get(`http://localhost:3001/getPatents`);
        setPatient(response.data);
      } catch (error) {
        console.error('Error fetching patient details:', error);
      }
    };

    fetchPatient();
  }, [id]);

  if (!patient) return <div>Loading...</div>;

  return (
    <div>
      <h1>Patient Details</h1>
      {patient.map((patient) => (
        <div key={patient.id}>
          <p>Name: {patient.name}</p>
          <p>Age: {patient.age}</p>
          <p>Bed Allotted: {patient.bedAllotted ? 'Yes' : 'No'}</p>
          <p>Discharged: {patient.isDischarged ? 'Yes' : 'No'}</p>
          <hr />
        </div>
      ))}
    </div>
  );
}

export default PatientDetails;
