import React, { useState, useEffect } from 'react';
import './PatientList.css'
import axios from 'axios';
import { Link } from 'react-router-dom';

function PatientList() {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      const response = await axios.get('http://localhost:3001/getPatents');
      setPatients(response.data);
    } catch (error) {
      console.error('Error fetching patients:', error);
    }
  };

  const dischargePatient = async (id) => {
    try {
      await axios.put(`http://localhost:3001/discharge/${id}`);
      fetchPatients();
    } catch (error) {
      console.error('Error discharging patient:', error);
    }
  };

  return (
    <div>
      <h1>All Patients</h1>
      <Link to="/add-patient" className="btn btn-primary">Add New Patient</Link>
      <ul>
        {patients.map((patient) => (
          <li key={patient._id}>
            {patient.name} - {patient.age} years old 
            <button onClick={() => dischargePatient(patient._id)}>Discharge</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PatientList;
