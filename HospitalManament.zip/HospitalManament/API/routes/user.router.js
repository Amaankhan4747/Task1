import express from 'express';
const router = express.Router();
import { getAllPatients, addNewPatient, dischargePatient } from '../controller/user.controller.js'

router.get('/getPatents', getAllPatients); // Display all patients
router.post('/add', addNewPatient); // Add new patient
router.put('/discharge/:id', dischargePatient); // Discharge patient


export default router;