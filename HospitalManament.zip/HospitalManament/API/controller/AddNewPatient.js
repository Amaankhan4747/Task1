// Add New Patient
export const addNewPatient = async (req, res) => {
    const { name, age, bedAllotted } = req.body;

    try {
        // Check if beds are available
        const totalBeds = 100; // Example total number of beds
        const occupiedBeds = await Patient.countDocuments({ bedAllotted: true, isDischarged: false });

        if (occupiedBeds >= totalBeds) {
            return res.status(400).json({ message: 'No beds available' });
        }

        const newPatient = new Patient({ name, age, bedAllotted: true });
        await newPatient.save();
        res.status(201).json(newPatient); // Return the newly added patient details
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
