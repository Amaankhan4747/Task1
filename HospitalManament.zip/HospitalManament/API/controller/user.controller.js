import Patient from '../models/user.model.js';
import '../models/connection.js'

// Get All Patients
export const getAllPatients = async (req, res) => {
    try {
        const patients = await Patient.find({ isDischarged: false });
        res.json(patients);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Add New Patient
export const addNewPatient = async (req, res) => {
    const { name, age, bedAllotted } = req.body;

    try {
        // Check if beds are available
        const totalBeds = 100; // Example total number of beds
        const occupiedBeds = await Patient.countDocuments({ bedAllotted: true, isDischarged: false });

        if (occupiedBeds >= totalBeds) {
            return res.status(400).json({ message: 'No beds available' });
        }

        const newPatient = new Patient({ name, age, bedAllotted: true });
        await newPatient.save();
        res.status(201).json(newPatient);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Discharge Patient
export const dischargePatient = async (req, res) => {
    const { id } = req.params;

    try {
        const patient = await Patient.findById(id);
        if (!patient) return res.status(404).json({ message: 'Patient not found' });

        patient.isDischarged = true;
        patient.bedAllotted = false;
        await patient.save();
        res.json({ message: 'Patient discharged successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
