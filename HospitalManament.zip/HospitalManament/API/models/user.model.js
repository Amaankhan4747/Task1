import mongoose from 'mongoose';

const patientSchema = new mongoose.Schema({
    name: { type: String, required: true },
    age: { type: Number, required: true },
    bedAllotted: { type: Boolean, required: true, default: false },
    isDischarged: { type: Boolean, required: true, default: false },
});

const PatientShemaModel = mongoose.model('Patient_collection', patientSchema);


export default PatientShemaModel