import express from 'express';
import bodyParser from 'body-parser';
import patientRoutes from './routes/user.router.js';
import cors from 'cors';

const app = express();

//to link routers


//configuration to fetch req body content : body parser middleware
//used to fetch req data from methods like : POST , PUT , PATCH , DELETE
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

//to allow cross origin request
app.use(cors({
    origin: 'http://localhost:3000', // Allow requests from this origin,
    credentials:true
}));

//route level middleware to load routes
app.use(patientRoutes);


app.listen(3001);
console.log("server invoked at link http://localhost:3001");