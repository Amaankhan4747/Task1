import SignUp from './components/SingUp';
import DoctorList from './components/DoctorList';
import EditDoctor from './components/EditDoctor';
import './App.css';
import DoctorDetail from './components/DoctorDetails';

const App = () => {
  return (

    <div className="App">
      <h1>Sign Up</h1>
      <SignUp />
      <DoctorList />
      <DoctorDetail />
      <EditDoctor />
    </div>

  )
};

export default App;
