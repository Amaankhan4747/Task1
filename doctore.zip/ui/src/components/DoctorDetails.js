import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom'; // Assuming you're using React Router for routing

const DoctorDetail = () => {
  const { id } = useParams(); // Get the ID from the route parameters
  const [doctor, setDoctor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDoctor = async () => {
      try {
        const response = await axios.get(`https://sample.rupioo.com/doctorPanel/viewById/${id}`);
        console.log('API Response:', response.data);
        setDoctor(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Fetch Doctor Error:', error);
        setError(error);
        setLoading(false);
      }
    };

    fetchDoctor();
  }, [id]);

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error loading doctor details: {error.message}</p>;
  }

  if (!doctor) {
    return <p>No doctor found with ID {id}</p>;
  }

  return (
    <div>
      <h2>Doctor Details</h2>
      <table border="1" cellPadding="10" cellSpacing="0" style={{ width: '100%', borderCollapse: 'collapse' }}>
        <tbody>
          <tr>
            <th>ID</th>
            <td>{doctor.id}</td>
          </tr>
          <tr>
            <th>Full Name</th>
            <td>{doctor.fullname}</td>
          </tr>
          <tr>
            <th>Email</th>
            <td>{doctor.email}</td>
          </tr>
          <tr>
            <th>Mobile Number</th>
            <td>{doctor.mobileNumber}</td>
          </tr>
          <tr>
            <th>City</th>
            <td>{doctor.city}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default DoctorDetail;
