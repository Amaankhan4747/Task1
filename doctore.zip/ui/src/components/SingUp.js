import React, { useState } from 'react';
import axios from 'axios';

const SignUp = () => {
    const [formData, setFormData] = useState({
        image: null,
        fullname: '',
        email: '',
        mobileNumber: '',
        password: '',
        confirmPassword: '',
        city: ''
    });
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        setFormData({
            ...formData,
            [name]: files ? files[0] : value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Basic client-side validation
        if (formData.password !== formData.confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        const formDataToSend = new FormData();
        for (const key in formData) {
            formDataToSend.append(key, formData[key]);
        }

        try {
            const response = await axios.post('https://sample.rupioo.com/doctorPanel/signup', formDataToSend, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log('SignUp Success:', response.data);
            setError(null); // Clear any previous errors
        } catch (error) {
            setError(`SignUp Error: ${error.response?.data?.message || error.message}`);
            console.error('SignUp Error:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <input type="file" name="image" onChange={handleChange} required />
            <input type="text" name="fullname" value={formData.fullname} onChange={handleChange} placeholder="Full Name" required />
            <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email" required />
            <input type="text" name="mobileNumber" value={formData.mobileNumber} onChange={handleChange} placeholder="Mobile Number" required />
            <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password" required />
            <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} placeholder="Confirm Password" required />
            <input type="text" name="city" value={formData.city} onChange={handleChange} placeholder="City" required />
            <button type="submit">Sign Up</button>
        </form>
    );
};

export default SignUp;
