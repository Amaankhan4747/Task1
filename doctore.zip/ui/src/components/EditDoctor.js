import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EditDoctor = ({ doctor, onDoctorUpdated }) => {
  const [formData, setFormData] = useState({
    fullname: '',
    email: '',
    mobileNumber: '',
    city: '',
  });
  const [error, setError] = useState(null);

  useEffect(() => {
    if (doctor) {
      setFormData({
        fullname: doctor.fullname || '',
        email: doctor.email || '',
        mobileNumber: doctor.mobileNumber || '',
        city: doctor.city || '',
      });
    }
  }, [doctor]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.put(`https://sample.rupioo.com/doctorPanel/doctor-edit/${doctor.id}`, formData);
      console.log('Edit Doctor Success:', response.data);
      onDoctorUpdated(response.data);
    } catch (error) {
      setError(`Edit Doctor Error: ${error.response?.data?.message || error.message}`);
      console.error('Edit Doctor Error:', error);
    }
  };

  return (
    <div>
      <h2>Edit Doctor</h2>
      <form onSubmit={handleSubmit}>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <input
          type="text"
          name="fullname"
          value={formData.fullname}
          onChange={handleChange}
          placeholder="Full Name"
          required
        />
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Email"
          required
        />
        <input
          type="text"
          name="mobileNumber"
          value={formData.mobileNumber}
          onChange={handleChange}
          placeholder="Mobile Number"
          required
        />
        <input
          type="text"
          name="city"
          value={formData.city}
          onChange={handleChange}
          placeholder="City"
          required
        />
        <button type="submit">Update Doctor</button>
      </form>
    </div>
  );
};

export default EditDoctor;
