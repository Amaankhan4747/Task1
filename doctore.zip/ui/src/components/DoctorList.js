import React, { useState, useEffect } from 'react';
import axios from 'axios';
import EditDoctor from './EditDoctor';

const DoctorList = () => {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingDoctor, setEditingDoctor] = useState(null);

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const response = await axios.get('https://sample.rupioo.com/doctorPanel/viewAll');
        console.log('API Response:', response);

        // Checking if the response data is an array
        const doctorsData = Array.isArray(response.data) ? response.data : response.data.doctors || [];
        setDoctors(doctorsData);
        setLoading(false);
      } catch (error) {
        // Log detailed error information
        console.error('Fetch Doctors Error:', error.response ? error.response.data : error.message);
        setError(error.response ? error.response.data : { message: error.message });
        setLoading(false);
      }
    };

    fetchDoctors();
  }, []);

  const handleDoctorUpdated = (updatedDoctor) => {
    setDoctors((prevDoctors) =>
      prevDoctors.map((doctor) =>
        doctor.id === updatedDoctor.id ? updatedDoctor : doctor
      )
    );
    setEditingDoctor(null);
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error loading doctors: {error.message}</p>;
  }

  return (
    <div>
      <h2>Doctors List</h2>
      <table border="1" cellPadding="10" cellSpacing="0" style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>City</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {doctors.map((doctor) => (
            <tr key={doctor.id}>
              <td>{doctor.id}</td>
              <td>{doctor.fullname}</td>
              <td>{doctor.email}</td>
              <td>{doctor.mobileNumber}</td>
              <td>{doctor.city}</td>
              <td>
                <button onClick={() => setEditingDoctor(doctor)}>Edit</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {editingDoctor && (
        <EditDoctor doctor={editingDoctor} onDoctorUpdated={handleDoctorUpdated} />
      )}
    </div>
  );
};

export default DoctorList;
