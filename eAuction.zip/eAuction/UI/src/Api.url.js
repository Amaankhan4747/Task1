export const _userapiurl="http://localhost:3001/user/";

export const _categoryapiurl="http://localhost:3001/category/";

export const _subcategoryapiurl="http://localhost:3001/subcategory/";

export const _productapiurl="http://localhost:3001/product/";

export const _bidapiurl="http://localhost:3001/bid/";