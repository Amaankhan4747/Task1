module.exports = {
    tabWidth: 4,
    singleQuote: true,
    semi: true,
};
