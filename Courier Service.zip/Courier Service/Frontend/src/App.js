import React from 'react';
import './App.css';
import { Routes, Route } from 'react-router-dom';
import Courier from './components/Courier';
import ShipmentForm from './components/ShipmentForm';

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Courier />} />
      <Route path="/shipment" element={<ShipmentForm />} />
    </Routes>
  );
};

export default App;