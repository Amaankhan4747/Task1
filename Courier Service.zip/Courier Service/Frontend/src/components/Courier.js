import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Courier.css'; // Import the CSS file

const Courier = () => {
  const [formData, setFormData] = useState({
    originPin: '',
  });
  const [availability, setAvailability] = useState(null);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const checkAvailability = async () => {
    const response = await axios.post('http://localhost:5000/check-availability', { originPin: formData.originPin });
    setAvailability(response.data.available);

    if (response.data.available) {
      navigate('/shipment');
    }
  };

  return (
    <div>
      <h1>Courier Service</h1>
      <form>
        <div>
          <label>Origin Pin Code:</label>
          <input type="text" name="originPin" value={formData.originPin} onChange={handleChange} />
        </div>
        <button type="button" onClick={checkAvailability}>Check Availability</button>
        {availability !== null && <div>Service Available
          {availability ? 'Yes' : 'No'}</div>}
      </form>
    </div>
  );
};

export default Courier;