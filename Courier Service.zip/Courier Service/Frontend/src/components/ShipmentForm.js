import React, { useState } from 'react';
import axios from 'axios';
import './ShipmentForm.css'; // Import the CSS file

const ShipmentForm = () => {
  const [formData, setFormData] = useState({
    originPin: '',
    destinationPin: '',
    productType: '',
    serviceType: '',
    bookingDate: '',
    weight: '',
    customerMobile: ''
  });
  const [availability, setAvailability] = useState(null);
  const [rate, setRate] = useState(null);
  const [trackingId, setTrackingId] = useState(null);
  const [trackingInfo, setTrackingInfo] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const checkAvailability = async () => {
    const response = await axios.post('http://localhost:5000/check-availability', { destinationPin: formData.destinationPin });
    setAvailability(response.data.available);
  };

  const checkRate = async () => {
    const response = await axios.post('http://localhost:5000/check-rate', formData);
    setRate(response.data.rate);
  };

  const bookShipment = async () => {
    const response = await axios.post('http://localhost:5000/book-shipment', formData);
    setTrackingId(response.data.trackingId);
  };

  const trackShipment = async () => {
    const response = await axios.get(`http://localhost:5000/track-shipment/${trackingId}`);
    setTrackingInfo(response.data);
  };

  return (
    <div>
      <h1>Add Details</h1>
      <form>
        <div>
          <label>Origin Pin Code:</label>
          <input type="text" name="originPin" value={formData.originPin} onChange={handleChange} />
        </div>
        <div>
          <label>Destination Pin Code:</label>
          <input type="text" name="destinationPin" value={formData.destinationPin} onChange={handleChange} />
        </div>
        <div>
          <label>Product Type:</label>
          <input type="text" name="productType" value={formData.productType} onChange={handleChange} />
        </div>
        <div>
          <label>Service Type:</label>
          <input type="text" name="serviceType" value={formData.serviceType} onChange={handleChange} />
        </div>
        <div>
          <label>Booking Date:</label>
          <input type="date" name="bookingDate" value={formData.bookingDate} onChange={handleChange} />
        </div>
        <div>
          <label>Weight:</label>
          <input type="text" name="weight" value={formData.weight} onChange={handleChange} />
        </div>
        <div>
          <label>Customer Mobile:</label>
          <input type="text" name="customerMobile" value={formData.customerMobile} onChange={handleChange} />
        </div>
        <button type="button" onClick={checkAvailability}>Check Now</button>
        {availability !== null && <div>Service Available: {availability ? 'Yes' : 'No'}</div>}
        {availability && <button type="button" onClick={checkRate}>Check Rate</button>}
        {rate !== null && <div>Rate: ${rate}</div>}
        {rate !== null && <button type="button" onClick={bookShipment}>Book Now</button>}
      </form>
      {trackingId && <div>Tracking ID: {trackingId}</div>}
      {trackingId && <button onClick={trackShipment}>Track Shipment</button>}
      {trackingInfo && (
        <div>
          <h2>Tracking Information</h2>
          <p>Status: {trackingInfo.status}</p>
          <p>Origin: {trackingInfo.originPin}</p>
          <p>Destination: {trackingInfo.destinationPin}</p>
          <p>Booking Date: {trackingInfo.bookingDate}</p>
          <p>Weight: {trackingInfo.weight}</p>
        </div>
      )}
    </div>
  );
};

export default ShipmentForm;