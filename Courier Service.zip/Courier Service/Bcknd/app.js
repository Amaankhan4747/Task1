
import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import cors from 'cors';


const app = express();
app.use(bodyParser.json());
app.use(cors());


mongoose.connect('mongodb://localhost:27017/courier-service');

const ShipmentSchema = new mongoose.Schema({
  originPin: String,
  destinationPin: String,
  productType: String,
  serviceType: String,
  bookingDate: Date,
  weight: Number,
  trackingId: String,
  status: String
});

const Shipment = mongoose.model('Shipment', ShipmentSchema);

app.post('/check-availability', (req, res) => {
  const { originPin } = req.body;

  if (originPin === '123456') {
    res.json({ available: false });
  } else {
    res.json({ available: true });
  }
});


app.post('/check-rate', (req, res) => {
  const { originPin, destinationPin, productType, serviceType, weight } = req.body;

  const rate = weight * 10;
  res.json({ rate });
});

app.post('/book-shipment', async (req, res) => {
  const { originPin, destinationPin, productType, serviceType, bookingDate, weight } = req.body;
  const trackingId = `TRK${Date.now()}`;

  const shipment = new Shipment({
    originPin,
    destinationPin,
    productType,
    serviceType,
    bookingDate,
    weight,
    trackingId,
    status: 'Booked'
  });
  await shipment.save();
  res.json({ trackingId });
});

app.get('/track-shipment/:trackingId', async (req, res) => {
  const { trackingId } = req.params;
  const shipment = await Shipment.findOne({ trackingId });
  if (shipment) {
    res.json(shipment);
  } else {
    res.status(404).json({ message: 'Shipment not found' });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});