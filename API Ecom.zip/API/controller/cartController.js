import Cart from '../models/cartModel.js';
import Product from '../models/productModel.js';
import '../models/connection.js';
// Add to Cart
export const addToCart = async (req, res) => {
  const { userId, productId, quantity } = req.body;

  try {
    // Check if the product exists
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Find the user's cart or create one
    let cart = await Cart.findOne({ userId });
    if (!cart) {
      cart = new Cart({ userId, items: [] });
    }

    // Check if the product is already in the cart
    const cartItemIndex = cart.items.findIndex(item => item.product.toString() === productId);
    if (cartItemIndex >= 0) {
      // Update the quantity if the product is already in the cart
      cart.items[cartItemIndex].quantity += quantity;
    } else {
      // Add the product to the cart
      cart.items.push({ product: productId, quantity });
    }

    await cart.save();
    res.status(200).json(cart);
  } catch (error) {
    res.status(500).json({ message: 'Error adding to cart' });
  }
};

// View Cart
export const viewCart = async (req, res) => {
    const { userId } = req.params;
  
    try {
      const cart = await Cart.findOne({ userId }).populate('items.product');
      if (!cart) {
        return res.status(404).json({ message: 'Cart not found' });
      }
  
      res.status(200).json(cart);
    } catch (error) {
      res.status(500).json({ message: 'Error viewing cart' });
    }
  };

  // Cart Summary
export const cartSummary = async (req, res) => {
    const { userId } = req.params;
  
    try {
      const cart = await Cart.findOne({ userId }).populate('items.product');
      if (!cart) {
        return res.status(404).json({ message: 'Cart not found' });
      }
  
      const totalPrice = cart.items.reduce((total, item) => {
        return total + item.product.price * item.quantity;
      }, 0);
  
      res.status(200).json({
        totalItems: cart.items.length,
        totalPrice,
        items: cart.items,
      });
    } catch (error) {
      res.status(500).json({ message: 'Error calculating cart summary' });
    }
  };
  
