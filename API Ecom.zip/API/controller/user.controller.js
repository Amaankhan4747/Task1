import '../models/connection.js';
import jwt from 'jsonwebtoken';
import rs from 'randomstring';
import url from 'url';

import UserSchemaModel from '../models/user.model.js';

export var save=async (req,res)=>{

 var usersList=await UserSchemaModel.find();    
 var l=usersList.length;
 var _id=l==0?1:usersList[l-1]._id+1;
 var userDetails={...req.body,"_id":_id,"role":"user","status":0,"info":Date()};
 
 try {
  await UserSchemaModel.create(userDetails);
  res.status(201).json({"status":true}); 
 }
 catch(error)
 {
    //console.log(error);
    res.status(500).json({"status":false});  
 } 
};


export var login=async (req,res)=>{  
 var condition_obj={...req.body,"status":1};         
 var usersList=await UserSchemaModel.find(condition_obj);
 if(usersList.length!=0)
 {
   const payload={"subject":usersList[0].email};     
   const key=rs.generate();
   const token=jwt.sign(payload,key);
   res.status(200).json({"token":token,"userDetails":usersList[0]});
 }
 else
   res.status(500).json({"token":"error"});
}; 

export var fetch=async(req,res)=>{
  var condition_obj=url.parse(req.url,true).query;    
  var userList=await UserSchemaModel.find(condition_obj);
  if(userList.length!=0)
    res.status(200).json(userList);
  else
    res.status(404).json({"status":"Resource not found"});
};

export var update=async(req,res)=>{
  let userDetails = await UserSchemaModel.findOne(JSON.parse(req.body.condition_obj));
  if(userDetails){
      let user=await UserSchemaModel.updateOne(JSON.parse(req.body.condition_obj),{$set: JSON.parse(req.body.content_obj)});   
      if(user)
        res.status(200).json({"msg":"success"});
      else
        res.status(500).json({"status": "Server Error"});
  }
  else
    res.status(404).json({"status":"Requested resource not available"});       
};

export var deleteUser=async(req,res)=>{
  let userDetails = await UserSchemaModel.findOne(JSON.parse(req.body.condition_obj));
  if(userDetails){
      let user=await UserSchemaModel.deleteOne(JSON.parse(req.body.condition_obj));   
      if(user)
        res.status(200).json({"msg":"success"});
      else
        res.status(500).json({"status": "Server Error"});
  }
  else
    res.status(404).json({"status":"Requested resource not available"});       
};

//forgate password
export var forgotPassword = async (req, res) => {
  const { email } = req.body;

  try {
      // Check if the user exists
      const user = await UserSchemaModel.findOne({ email });
      if (!user) {
          return res.status(404).json({ status: "User not found" });
      }

      // Generate reset token and its expiration time
      const resetToken = jwt.sign({ email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
      
      // Save the token and expiration in the user document
      user.resetPasswordToken = resetToken;
      user.resetPasswordExpires = Date.now() + 3600000; // 1 hour
      await user.save();

      // Simulate email sending (In real case, use a mail service like nodemailer)
      res.status(200).json({ status: "Password reset token generated", token: resetToken });

  } catch (error) {
      res.status(500).json({ status: "Server Error", error });
  }
};

//resetPassword-----//
export var resetPassword = async (req, res) => {
  const { resetToken, newPassword } = req.body; // Ensure resetToken is being passed correctly

  if (!resetToken) {
    return res.status(400).json({ status: "Token is missing" });
  }

  try {
      // Decode the reset token
      const decoded = jwt.verify(resetToken, process.env.JWT_SECRET);

      // Find the user with the reset token and check if the token has expired
      const user = await UserSchemaModel.findOne({
          email: decoded.email,
          resetPasswordToken: resetToken,
          resetPasswordExpires: { $gt: Date.now() } // Check if token is still valid
      });

      if (!user) {
          return res.status(400).json({ status: "Invalid or expired reset token" });
      }

      // Update the password and clear the reset token fields
      user.password = newPassword;  // Make sure to hash the password before saving
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;
      await user.save();

      res.status(200).json({ status: "Password has been reset successfully" });

  } catch (error) {
      if (error.name === "TokenExpiredError") {
          return res.status(400).json({ status: "Token has expired" });
      }
      return res.status(500).json({ status: "Server Error", error: error.message });
  }
};



