import exprees from 'express';
import UserSchemaModel from '../models/user.model';
export var save = async(req,res)=>{
var userList=await UserSchemaModel.find();
var l=userList.length;
var _id=l==0?1:userList[l-1]._id+1;
var userDetails={...req.body, "role":'user', _id:"id", "status":0, "info":Date()}
try{
    await UserSchemaModel.craete(userDetails);
    res.status(201).json({"status":true});
}
catch(error){
    res.status(500).json({"status":false});
}
}

export var login=async(req,res)=>{
    var conditional_obj={...req.body, "status":1}
    var userList=UserSchemaModel.find(conditional_obj);
    if(userList.length!=0){
        const payload=("subject", userList[0].email)
        const key=rs.genrate();
        const token=JWT.sing(payload.key);
        res.status(200).json({"token":token, "userDetails":userList[0]})
    }else{
       res.status(404).json({"token":"error"}); 
    }
}
export var fatch=async(req,res)=>{
    var conditional_obj=url.parse(req.url,true).query;
    var userList=UserSchemaModel.find(conditional_obj);
    if(userList.length!=0){
        res.status(200).json("fetch", userList)
    }
    else{
    res.status(404).json({"status":"the reasources not found"})
    }
}