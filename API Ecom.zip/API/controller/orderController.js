import Order from '../models/orderModel.js';
import '../models/connection.js';
// Checkout Process
export const checkout = async (req, res) => {
  const { userId, items, billingAddress, shippingAddress, totalAmount } = req.body;

  try {
    const order = new Order({
      userId,
      items,
      billingAddress,
      shippingAddress,
      totalAmount,
      expectedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days delivery time
    });

    await order.save();
    res.status(200).json({ message: 'Order placed successfully', order });
  } catch (error) {
    res.status(500).json({ message: 'Error during checkout', error });
  }
};

// Order Confirmation
export const orderConfirmation = async (req, res) => {
    const { orderId } = req.params;
  
    try {
      const order = await Order.findById(orderId).populate('items.product');
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
  
      res.status(200).json({ 
        message: 'Order confirmed', 
        orderDetails: order 
      });
    } catch (error) {
      res.status(500).json({ message: 'Error fetching order confirmation', error });
    }
  };

  // Order History
export const orderHistory = async (req, res) => {
    const { userId } = req.params;
  
    try {
      const orders = await Order.find({ userId }).populate('items.product');
      if (!orders) {
        return res.status(404).json({ message: 'No orders found' });
      }
  
      res.status(200).json(orders);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching order history', error });
    }
  };
  
  // Cancel Order
export const cancelOrder = async (req, res) => {
    const { orderId } = req.params;
  
    try {
      const order = await Order.findById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      if (order.cancelled) {
        return res.status(400).json({ message: 'Order already cancelled' });
      }
  
      order.cancelled = true;
      order.orderStatus = 'Cancelled';
      await order.save();
  
      res.status(200).json({ message: 'Order cancelled successfully', order });
    } catch (error) {
      res.status(500).json({ message: 'Error cancelling order', error });
    }
  };
  
  // Delete Order
  export const deleteOrder = async (req, res) => {
    const { orderId } = req.params;
  
    try {
      const order = await Order.findByIdAndDelete(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      res.status(200).json({ message: 'Order deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Error deleting order', error });
    }
  };