import express from 'express';
import { checkout, orderConfirmation, orderHistory, cancelOrder, deleteOrder } from '../controller/orderController.js';

const router = express.Router();

// Order routes
router.post('/checkout', checkout); // Checkout Process
router.get('/confirmation/:orderId', orderConfirmation); // Order Confirmation
router.get('/history/:userId', orderHistory); // Order History
router.put('/cancel/:orderId', cancelOrder); // Cancel Order
router.delete('/:orderId', deleteOrder); // Delete Order

export default router;
