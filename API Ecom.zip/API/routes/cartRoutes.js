import express from 'express';
import { addToCart, viewCart, cartSummary } from '../controller/cartController.js';

const router = express.Router();

// Cart routes
router.post('/cart', addToCart); // Add to Cart
router.get('/cart/:userId', viewCart); // View Cart
router.get('/cart-summary/:userId', cartSummary); // Cart Summary

export default router;
