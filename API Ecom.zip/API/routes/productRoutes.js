import express from 'express';
import {
  getAllProducts,
  getProductById,
  createProduct,
  searchProducts,
  updateProduct,
  deleteProduct
//   createCategory,
//   getAllCategories
} from '../controller/productController.js';

const router = express.Router();

// Product routes
router.get('/products', getAllProducts);
router.get('/products/:id', getProductById);
router.post('/products', createProduct);
router.get('/search', searchProducts);
router.put('/:productId', updateProduct); // Update Product
router.delete('/:productId', deleteProduct); // Delete Product
// Category routes
// router.post('/categories', createCategory);
// router.get('/categories', getAllCategories);

export default router;
