import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';

const app = express();
dotenv.config();
//to link routers
import productRoutes from './routes/productRoutes.js';
import UserRouter from './routes/user.router.js';
import cartRoutes from './routes/cartRoutes.js';
import orderRoutes from './routes/orderRoutes.js'
//configuration to fetch req body content : body parser middleware
//used to fetch req data from methods like : POST , PUT , PATCH , DELETE

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

//to allow cross origin request
app.use(cors());

//route level middleware to load routes
app.use("/user",UserRouter);
app.use('/api', productRoutes);
app.use('/carts', cartRoutes);
app.use('/orders', orderRoutes);


app.listen(3001);
console.log("server invoked at link http://localhost:3001");