import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  items: [
    {
      product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
      quantity: { type: Number, required: true },
    }
  ],
  totalAmount: { type: Number, required: true },
  billingAddress: { type: String, required: true },
  shippingAddress: { type: String, required: true },
  paymentStatus: { type: String, default: 'Pending' },
  orderStatus: { type: String, default: 'Processing' },
  orderDate: { type: Date, default: Date.now },
  expectedDelivery: { type: Date },
  cancelled: { type: Boolean, default: false }
});

const Order = mongoose.model('Order', orderSchema);
export default Order;
