import mongoose from 'mongoose';

// Category Schema
// const categorySchema = new mongoose.Schema({
//   name: { type: String, required: true },
// });

// Product Schema
const productSchema = new mongoose.Schema({
  name: { type: String, required: false },
  description: { type: String, required: false },
  price: { type: String, required: false },
  image: { type: String, required: false },
//   category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' }, // Referencing Category schema
});

// Create models for both Product and Category
// const Category = mongoose.model('Category', categorySchema);
const Product = mongoose.model('Product', productSchema);

// Export both models
export default Product;
