import React from 'react';
import { useState } from "react";


function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mobile, setMobile] = useState("");
  const [address, setAddres] = useState("");
  const [city, setCity] = useState("");
  const [gender, setGender] = useState("");

  const handleSubmit = () => {
    const userDetails = {
      name: name,
      email: email,
      password: password,
      mobile: mobile,
      address: address,
      city: city,
      gender: gender,
    };
    console.log(userDetails);
    alert("test");
    setName("");
    setEmail("");
    setPassword("");
    setMobile("");
    setAddres("");
    setCity("");
  }
  return (
    <>
      <from>
        <h2>Register Here !</h2>

        <div class="form-group">
          <label>Full Name</label>
          <input
            type="name"
            class="form-control"
            placeholder="Enter name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input
            type="text"
            class="form-control"
            placeholder="Enter Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div class="form-group">
          <label>Password</label>
          <input
            type="password"
            class="form-control"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div class="form-group">
          <label>Moblie</label>
          <input
            type="text"
            class="form-control"
            placeholder="Enter number"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
          />
        </div>
        <div class="form-group">
          <label>Address</label>
          <input
            type="textarea"
            class="form-control"
            placeholder="Enter address"
            value={address}
            onChange={(e) => setAddres(e.target.value)}
          />
        </div>
        <div class="form-group">
          <label for="city">City:</label>
          <select
            class="form-control"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          >
            <option>Select City</option>
            <optgroup label="MP">
              <option>Indore</option>
              <option>Ujjain</option>
              <option>Bhopal</option>
            </optgroup>
            <optgroup label="MH">
              <option>Mumbai</option>
              <option>Pune</option>
              <option>Nasik</option>
            </optgroup>

            <optgroup label="RJ">
              <option>Jaipur</option>
              <option>udaipur</option>
              <option>chittorgarh</option>
            </optgroup>
          </select>
        </div>
        <div class="form-group">
          <label for="gender">Gender:</label>
          &nbsp;&nbsp; Male{" "}
          <input
            type="radio"
            value="male"
            name="gender"
            onChange={(e) => setGender(e.target.value)}
          />
          &nbsp;&nbsp; Female{" "}
          <input
            type="radio"
            value="female"
            name="gender"
            onChange={(e) => setGender(e.target.value)}
          />
        </div>
        <br />
        <button
          type="button"
          class="btn btn-primary"
          onClick={handleSubmit}
        >
          Submit
        </button>

      </from>
    </>
  );
}

export default Register