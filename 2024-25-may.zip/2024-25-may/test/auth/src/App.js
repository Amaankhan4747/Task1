import React from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import Header from './components/HeaderComponets/Header';
import Login from './components/LoginComponent/Login';
import Register from './components/RegisterComponent/Register';

const Navbar = () => (
  <nav style={{ padding: '10px', backgroundColor: '#eee' }}>
    <ul style={{ listStyleType: 'none', margin: 0, padding: 0, display: 'flex', gap: '10px' }}>
      <li>
        <Link to="/login">Login</Link>
      </li>
      <li>
        <Link to="/register">Register</Link>
      </li>
    </ul>
  </nav>
);

const App = () => (
  <Router>
    <div>
      <Header />
      <Navbar />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </div>
  </Router>
);

export default App;
