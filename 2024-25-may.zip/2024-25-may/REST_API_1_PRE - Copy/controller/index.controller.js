import '../models/connection.js';
import jwt from 'jsonwebtoken';
import rs from 'randomstring';
import UserSchemaModel from '../models/user.model.js';

export var save = async (req, res) => {
  var UserList = await UserSchemaModel.find();

  var l = UserList.length;
  var _id = l == 0 ? 1 : UserList[l - 1]._id + 1;
  var UserDetails = { ...req.body, "_id": _id, "role": "user", "status": 0, "info": Date() };

  try {

    await UserSchemaModel.create(UserDetails);
    res.status(201).json({ "status": true });


  }
  catch (error) {
    res.status(500).json({ "status": false });
  }
};

export var login = async (req, res) => {
  var condition_obj = { ...req.body, "status": 1 };
  var UserList = await UserSchemaModel.find(condition_obj);
  if (UserList.length !== 0) {
    const payload = { "subject": UserList[0].email };
    const key = rs.generate()
    const token = jwt.sign(payload, key)
    res.status(200).json({ "token": token, "UserDetails": UserList[0] });
  }
  else res.send(500).json({ "token": "error" });
};
