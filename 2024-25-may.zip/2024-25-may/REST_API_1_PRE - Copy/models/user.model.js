import mongoose from "mongoose";
import uniqueValidator from 'mongoose-unique-validator';

const UserSchema=mongoose.Schema({
  _id:Number,
  name:{
    type:String,
    required:[true, "name is required"],
    lowercase:true,
    trim:true,
  },

  email:{
  type:String,
    required:[true, "email is required"],
    unique:true,
    lowercase:true,
    trim:true,
  },

  password:{
    type:String,
    required:[true, "password is required hard"],
    trim:true,
    maxlength:12,
    minlength:5,
  },

  mobile:{
    type:String,
    required:[true,"Mobile is required"],
    maxlength:10,
    minlength:10,
    trim:true
  },
  address:{
    type:String,
    required:[true,"Address is required"],
    trim:true
},
city:{
    type:String,
    required:[true,"City is required"],
    trim:true
},

gender:{
    type:String,
    required:[true,"Gender is required"],

},
role:String,
status:Number,
info:String
});

UserSchema.plugin(uniqueValidator);

const UserSchemaModel=mongoose.model('User_Collection',UserSchema);
export default UserSchemaModel;