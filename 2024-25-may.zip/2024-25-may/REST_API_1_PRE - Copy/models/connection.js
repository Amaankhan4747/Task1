import mongoose from "mongoose";
const url = "mongodb://localhost:27017/reactapi";
mongoose.connect(url);
console.log("Successfully connected to mongoDB databased");
