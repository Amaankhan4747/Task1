import express from 'express';
const UserRouter=express.Router();

import * as IndexController from '../controller/index.controller.js'
 
UserRouter.post("/save",IndexController.save);
UserRouter.post("/login",IndexController.login);

export default UserRouter;