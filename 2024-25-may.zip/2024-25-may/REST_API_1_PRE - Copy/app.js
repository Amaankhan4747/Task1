import express from "express";
import bodyParser from "body-parser";

const app = express();

// link routers
import UserRouter from "./router/User.router.js";
// body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// port
app.use("/user", UserRouter);
app.listen(3001);
console.log("the server is ready http://localhost:3001");
