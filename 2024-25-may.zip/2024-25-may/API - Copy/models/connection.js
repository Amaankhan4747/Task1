import mongoose from "mongoose";
const url="mongodb://localhost:27017/mern-6may";
mongoose.connect(url);
console.log("successfully connected to mongoDB databased..!!");