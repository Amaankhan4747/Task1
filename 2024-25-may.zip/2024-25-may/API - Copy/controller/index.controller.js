
import '../models/connection.js';
import UserSchemaModel from '../models/users.models.js';
export var save=(req,res)=>{
console.log(req.body);
res.send("its working");
};