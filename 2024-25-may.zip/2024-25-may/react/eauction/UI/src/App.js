import "./App.css";
import { Routes, Route } from "react-router-dom";
import Header from "./components/HeaderComponent/Header";
import Banner from "./components/BannerComponent/Banner";
import Home from "./components/HomeComponent/Home";
import Userhome from "./components/UserComponent/Userhome";
import About from "./components/AboutComponent/About";
import Contact from "./components/ContactComponents/Contact";
import Service from "./components/ServiceComponent/Service";
import Login from "./components/LoginComponent/Login";
import Register from "./components/RegisterComponent/Register";
import Footer from "./components/FooterComponent/Footer";
import Logout from "./components/LogoutComponent/Logout";
import Admin from "./components/AdminComponent/Admin";
import Manageuser from "./components/ManageuserComponent/Manageuser";
import EPAdmin from "./components/EPAdminComponent/EPAdmin";
import CPAdmin from "./components/CPAdminComponent/CPAdmin";
import Addsubcategory from "./components/AddsubcategoryComponent/Addsubcategory";
import Addcategory from "./components/AddcategoryComponent/Addcategory";
import Viewproductcategory from "./components/ViewProductCategoryComponent/Viewproductcategory";
import Viewproductsubcategory from "./components/ViewProductSubCategoryComponent/Viewproductsubcategory";
import Addproducts from "./components/AddproductComponent/Addproducts";
import Viewproducts from "./components/ViewProductsComponent/Viewproducts";
function App() {
  return (
    <>

      <div class="hero_area">
        <Header />
        <Banner />
      </div>

      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/user" element={<Userhome />}></Route>
        <Route path="/about" element={<About />}></Route>
        <Route path="/service" element={<Service />}></Route>
        <Route path="/contact" element={<Contact />}></Route>
        <Route path="/service" element={<Service />}></Route>
        <Route path="/register" element={<Register />}></Route>
        <Route path="/login" element={<Login />}></Route>
        <Route path="/logout" element={<Logout />}></Route>
        <Route path="/admin" element={<Admin />}></Route>
        <Route path="/manageusers" element={<Manageuser />}></Route>
        <Route path="/cpadmin" element={<CPAdmin />}></Route>
        <Route path="/epadmin" element={<EPAdmin />}></Route>
        <Route path="/addproducts" element={<Addproducts />}></Route>
        <Route path="/addsubcategory" element={<Addsubcategory />}></Route>
        <Route path="/addcategory" element={<Addcategory />}></Route>
        <Route path="/viewpc" element={< Viewproductcategory />}></Route>
        <Route path="/viewp/:subcatnm" element={< Viewproducts />}></Route>
        <Route path="/viewpsc/:catnm" element={< Viewproductsubcategory />}></Route>


      </Routes>

      <Footer />
    </>
  );
}

export default App;
