
import { useState, useEffect } from 'react';
function Banner() {

  const [BannerContent, setBannerContent] = useState();
  useEffect(() => {
    if (localStorage.getItem("token") != undefined) {
      setBannerContent(<>
        <section class=" slider_section position-relative" >
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="container">
                <div class="row">
                  <div class="col-md-7">
                    <div class="detail-box">
                      <div>
                        <h1 >
                          Welcome To Admin panel

                        </h1>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </section >
      </>);
    }
    else {
      setBannerContent(<>
        {/* slider section */}
        <section class=" slider_section position-relative">
          <div
            id="carouselExampleIndicators"
            class="carousel slide"
            data-ride="carousel"
          >
            <ol class="carousel-indicators">
              <li
                data-target="#carouselExampleIndicators"
                data-slide-to="0"
                class="active"
              >
                01
              </li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1">
                02
              </li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <div class="container">
                  <div class="row">
                    <div class="col-md-7">
                      <div class="detail-box">
                        <div>
                          <h1>
                            Welcome To <br />
                            <span>Online Portal Buy & Sell </span>
                          </h1>
                          <p>
                            It is a long established fact that a reader will be
                            distracted by the readable content of a page when
                            looking
                          </p>
                          <div class="btn-box">
                            <a href="" class="btn-1">
                              Contact Us
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="carousel-item">
                <div class="container">
                  <div class="row">
                    <div class="col-md-7">
                      <div class="detail-box">
                        <div>
                          <h1>
                            Welcome To <br />
                            <span>Online Portal Buy & Sell </span>
                          </h1>
                          <p style={{ color: "white" }}>
                            It is a long established fact that a reader will be
                            distracted by the readable content of a page when
                            looking
                          </p>
                          <div class="btn-box">
                            <a href="" class="btn-1">
                              Contact Us
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="custom_carousel-control">
              <a
                class="carousel-control-prev"
                href="#carouselExampleIndicators"
                role="button"
                data-slide="prev"
              >
                <span class="sr-only">Previous</span>
              </a>
              <a
                class="carousel-control-next"
                href="#carouselExampleIndicators"
                role="button"
                data-slide="next"
              >
                <span class="sr-only">Next</span>
              </a>
            </div>
          </div>
        </section>
        {/* end slider section */}
      </>)
    }
  })

  return (
    <>
      {BannerContent}
    </>
  );
}

export default Banner;
