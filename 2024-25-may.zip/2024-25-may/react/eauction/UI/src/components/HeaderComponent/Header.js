import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import Auth from "../authComponent/Auth";

function Header() {

  const [HeaderContent, setHeaderContent] = useState();
  useEffect(() => {
    if (localStorage.getItem("token") != undefined && localStorage.getItem("role") == "admin") {
      setHeaderContent(<>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="index.html"><Link to="/admin" style={{ color: "red" }}>
                  Admin Home
                </Link>
                  <span class="sr-only">(cu rrent)</span>
                </a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="index.html"><Link to="/manageusers" style={{ color: "red" }}>
                  Manageuser
                </Link>
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="settingsDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  style={{ "color": "#f95c37" }}> Settings
                </button>
                <div class="dropdown-menu" aria-labelledby="settingsDropdown">
                  <a class="dropdown-item"><Link style={{ "color": "black" }} to="/cpadmin">Change Password</Link></a>
                  <a class="dropdown-item"><Link style={{ "color": "black" }} to="/epadmin">Edit Profile</Link></a>
                </div>
              </li>
              &nbsp
              {/*----- manage category --*/}

              <li class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="settingsDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  style={{ "color": "#f95c37" }}> Manage Category
                </button>
                <div class="dropdown-menu" aria-labelledby="settingsDropdown">
                  <a class="dropdown-item"><Link style={{ "color": "black" }} to="/addcategory">Add Category</Link></a>
                  <a class="dropdown-item"><Link style={{ "color": "black" }} to="/addsubcategory">Add Subcategory</Link></a>
                </div>
              </li>


              <li class="nav-item">
                <a class="nav-link" href="">
                  <Link to="/logout" style={{ color: "red" }}>
                    Logout
                  </Link>
                </a>
              </li>
            </ul>
            <form class="form-inline">
              <button
                class="btn  my-2 my-sm-0 nav_search-btn"
                type="submit"
              ></button>
            </form>
          </div>
        </div>

      </>)
    }
    else if (localStorage.getItem("token") != undefined && localStorage.getItem("role") == "user") {
      setHeaderContent(<>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="index.html">
                  <Link to="/user" style={{ color: "red" }}>
                    User Home
                  </Link>
                  <span class="sr-only">(current)</span>
                </a>
              </li>

              <li class="nav-item active">
                <a class="nav-link" href="index.html">
                  <Link to="/viewpc" style={{ color: "red" }}>
                    View Product's
                  </Link>
                  <span class="sr-only">(current)</span>
                </a>
              </li>

              <li class="nav-item active">
                <a class="nav-link" href="index.html">
                  <Link to="/addproducts" style={{ color: "red" }}>
                    Add Product
                  </Link>
                  <span class="sr-only">(current)</span>
                </a>
              </li>



              <li class="nav-item">
                <a class="nav-link" href="">
                  <Link to="/logout" style={{ color: "red" }}>
                    Logout
                  </Link>
                </a>
              </li>
            </ul>
          </div>
        </div>

      </>)
    } else {
      setHeaderContent(<>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="index.html">
                  <Link to="/" style={{ color: "red" }}>
                    Home
                  </Link>
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.html">
                  {" "}
                  <Link to="/about" style={{ color: "red" }}>
                    About
                  </Link>{" "}
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="service.html">
                  {" "}
                  <Link to="/service" style={{ color: "red" }}>
                    Service
                  </Link>{" "}
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.html">
                  <Link to="/contact" style={{ color: "red" }}>
                    Contact us
                  </Link>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="">
                  <Link to="/register" style={{ color: "red" }}>
                    Register
                  </Link>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="">
                  <Link to="/login" style={{ color: "red" }}>
                    Login
                  </Link>
                </a>
              </li>
            </ul>
            <form class="form-inline">
              <button
                class="btn  my-2 my-sm-0 nav_search-btn"
                type="submit"
              ></button>
            </form>
          </div>
        </div>
      </>)
    }
  })


  return (
    <>
      <Auth />
      {/* header section strats */}
      <header class="header_section">
        <div class="container">
          <nav class="navbar navbar-expand-lg custom_nav-container pt-3">
            <a class="navbar-brand mr-5" href="index.html">
              <img
                src="assets/images/logom.png"
                alt=""
                style={{ height: "30px", width: "30px" }}
              />
              <span style={{ color: "red" }}>Auction Zone</span>
            </a>
            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            {HeaderContent}
          </nav>
        </div>
      </header>
      {/* end header section */}
    </>
  );
}

export default Header;
