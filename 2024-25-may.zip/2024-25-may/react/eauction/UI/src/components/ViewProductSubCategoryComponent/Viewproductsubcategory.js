import './Viewproductsubcategory.css'
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { _subcategoryapiurl } from '../../api.url';
import { Link, useParams } from 'react-router-dom';
function Viewproductsubcategory() {

  const params = useParams();
  const [scDetails, setSubCategoryDetails] = useState([]);

  useEffect(() => {
    axios.get(_subcategoryapiurl + "fetch?catnm=" + params.catnm).then((response) => {
      setSubCategoryDetails(response.data);
    }).catch((error) => {
      console.log(error);
    });
  });

  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="detail-box">
                <h2 style={{ textAlign: "center" }}>View Product Sub Category</h2>
                <div class="heading_container">
                  <br />
                </div>
              </div>
              <center>
                <div id="category_main">
                  {
                    scDetails.map((row) => (
                      <div class="category_part">
                        <Link to={`/viewp/${row.subcatnm}`} >
                          <img src={`../assets/uploads/subcaticons/${row.subcaticonnm}`} height="180" width="90" />
                          <br />
                          <b>{row.subcatnm}</b>
                        </Link>
                      </div>
                    ))
                  }
                </div>
              </center>

            </div>
            <div class="col-md-6">
              <div class="img-box">
                <img src="assets/images/logo" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}
    </>
  );
}

export default Viewproductsubcategory;
