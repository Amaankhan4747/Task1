import React, { useState } from 'react'
import axios from 'axios'
import { _categoryapiurl } from '../../api.url';

function Addproducts() {
  const [file, setFile] = useState();
  const [catName, setCatName] = useState();
  const [output, setOutput] = useState();



  const handleChange = (event) => {
    setFile(event.target.files[0]);
  }
  const handleSubmit = (event) => {
    // alert("check");
    event.preventDefault();
    var formData = new FormData();
    formData.append('catnm', catName);
    formData.append('caticon', file);
    const config = {
      'content-type': 'multipart/form-data'
    };
    axios.post(_categoryapiurl + "save", formData, config).then((response) => {
      setCatName("");
      setOutput("products Added Successfully....");
    });
  }


  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="detail-box">
                <div class="heading_container">
                  <h2> Add Category products</h2>
                </div>

                <form>
                  <font color="blue">{output}</font>
                  <div className="form-group">
                    <label>Products Name</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter Category title"
                      value={catName}
                      onChange={(e) => setCatName(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label>Category Icon</label>
                    <input
                      type="file"
                      className="form-control"
                      onChange={handleChange} />

                  </div>
                  <br />
                  <button
                    type="button"
                    className="btn"
                    onClick={handleSubmit}>

                    <a href="">Get Started</a>
                  </button>
                </form>


              </div>
            </div>
            <div class="col-md-6">
              <div class="img-box">
                <img src="assets/images/about-img.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}


    </>
  );
}

export default Addproducts;
