function Userhome() {
  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <h1>User Home </h1>
          <div class="row">
            <div class="col-md-6">
              <div class="detail-box">
                <div class="heading_container">
                  <h2> About/ home us components</h2>
                </div>
                <p>
                  It is a long established fact that a reader will be distracted
                  by the readable content of a page when looking at its layout.
                  The point of using Lorem Ipsum is that it has a more-or-less
                  normal distribution of letters, as opposed to using 'Content
                  here, content here', making it look like readable English.
                  Many desktop publishing packages and web page editors now use
                  Lorem Ipsum as their
                </p>
                <a href="">Get Started</a>
              </div>
            </div>
            <div class="col-md-6">
              <div class="img-box">
                <img src="assets/images/about-img.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}
    </>
  );
}

export default Userhome;
