import React, { useState } from 'react';
import axios from 'axios';
import { _userapiurl } from '../../api.url';
import { useNavigate } from 'react-router-dom';

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [output, setOutput] = useState();

  const handleSubmit = () => {
    const UserDetails = { "email": email, "password": password };
    // console.log("UserDetails:", UserDetails);

    axios.post(_userapiurl + "login", UserDetails)
      .then((response) => {
        var users = response.data.UserDetails;
        localStorage.setItem("token", response.data.token);
        localStorage.setItem("name", users.name);
        localStorage.setItem("_Id", users._id);

        localStorage.setItem("email", users.email);
        localStorage.setItem("mobile", users.mobile);
        localStorage.setItem("address", users.address);
        localStorage.setItem("city", users.city);
        localStorage.setItem("gender", users.gender);
        localStorage.setItem("info", users.info);
        localStorage.setItem("role", users.role);
        users.role == "admin" ? navigate("/admin") : navigate("/user");
      }).catch((error) => {

        setOutput("Invalid user or verify your account.");
        setEmail("");
        setPassword("");
      });
  };

  return (
    <>
      {/* about section */}
      <section className="about_section layout_padding">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="detail-box">
                <div className="heading_container">
                  <form>
                    <h2>Login Here!</h2>
                    <font color="blue">{output}</font>
                    <div className="form-group">
                      <label>Email Address</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Enter Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <label>Password</label>
                      <input
                        type="password"
                        className="form-control"
                        placeholder="Enter password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </div>
                    <br />
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={handleSubmit}
                    >
                      LOGIN
                    </button>
                  </form>
                </div>
              </div>
            </div>
            <div className="col-md-6">
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}
    </>
  );
}

export default Login;
