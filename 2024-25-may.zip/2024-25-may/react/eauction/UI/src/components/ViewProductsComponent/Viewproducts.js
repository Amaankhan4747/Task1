import React from 'react'
import './Viewproducts.css';
import { useState, useEffect } from 'react';
import axios from 'axios';
import { _productsapiurl } from '../../api.url';
import { Link, useParams } from 'react-router-dom';


function Viewproducts() {
  const params = useParams();
  const [pDetails, setProductsDetails] = useState([]);

  useEffect(() => {
    axios.get(_productsapiurl + "fetch?subcatnm=" + params.subcatnm).then((response) => {
      setProductsDetails(response.data);
    }).catch((error) => {
      console.log(error);
    });
  });
  return (
    <>

      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="detail-box">
                <div class="heading_container">
                  <h2 class="md-4">View Product List &gt;&gt; {params.subcatnm}</h2>


                </div>
              </div>
            </div>
            {
              pDetails.map((row) => (
                <center>
                  <table id="ptable" border="1">
                    <tr>
                      <td rowspan="3">
                        <center>
                          <img src={`../assets/uploads/picons/${row.piconnm}`} height="100" width="150" />
                        </center>
                      </td>
                      <td><b>Title : {row.title} </b></td>
                    </tr>
                    <tr>
                      <td><b>Description : {row.description}</b></td>
                    </tr>
                    <tr>
                      <td><b>Base price : {row.baseprice}</b></td>
                    </tr>
                  </table>
                </center>
              ))
            }

            <div class="col-md-6">
              <div class="img-box">
                <img src="assets/images/about-img.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}


    </>
  )
}

export default Viewproducts