import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { _categoryapiurl, _subcategoryapiurl, _productsapiurl } from '../../api.url';

function Addproducts() {
  const [file, setFile] = useState();
  const [title, setTitle] = useState();
  const [catName, setCatName] = useState();
  const [subCatName, setSubCatName] = useState();
  const [description, setDescription] = useState();
  const [baseprice, setBasePrice] = useState();
  const [output, setOutput] = useState();
  const [cDetails, setCategoryDetails] = useState([]);
  const [scDetails, setSubCategoryDetails] = useState([]);

  useEffect(() => {
    axios.get(_categoryapiurl + "fetch").then((response) => {
      setCategoryDetails(response.data);
    }).catch((error) => {
      console.log(error);
    });
  });


  const fetchSubCat = (catnm) => {
    setCatName(catnm);
    axios.get(_subcategoryapiurl + "fetch?catnm=" + catnm).then((response) => {
      setSubCategoryDetails(response.data);
    }).catch((error) => {
      setSubCategoryDetails([]);
    });
  }
  const handleChange = (event) => {
    setFile(event.target.files[0]);
  }
  const handleSubmit = (event) => {
    event.preventDefault();
    var formData = new FormData();
    formData.append('title', title);
    formData.append('catnm', catName);
    formData.append('subcatnm', subCatName);
    formData.append('description', description);
    formData.append('baseprice', baseprice);
    formData.append('uid', localStorage.getItem("email"));
    formData.append('picon', file);
    const config = {
      'content-type': 'multipart/form-data'
    };
    axios.post(_productsapiurl + "save", formData, config).then((response) => {
      setTitle("");
      setCatName("");
      setSubCatName("");
      setDescription("");
      setBasePrice("");
      setOutput("Product Added Successfully....");
    });
  }
  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="detail-box">
                <div class="heading_container">

                  <h2>Add Product Here!!! </h2>
                  <font style={{ "color": "blue" }} >{output}</font>
                </div>
                <form>
                  <div class="form-group">
                    <label for="title">Title:</label>
                    <input type="text" class="form-control" value={title} onChange={e => setTitle(e.target.value)} />
                  </div>
                  <br />
                  <div class="form-group">
                    <label for="catnm">Category Name:</label>
                    <select class="form-control" value={catName} onChange={e => fetchSubCat(e.target.value)}>
                      <option>Select Category</option>
                      {
                        cDetails.map((row) => (
                          <option>{row.catnm}</option>
                        ))
                      }
                    </select>
                  </div>
                  <br />
                  <div class="form-group">
                    <label for="catnm">Sub Category Name:</label>
                    <select class="form-control" value={subCatName} onChange={e => setCatName(e.target.value)}>
                      <option> Select Sub Category</option>
                      {
                        scDetails.map((row) => (
                          <option>{row.subcatnm}</option>
                        ))
                      }
                    </select>
                  </div>
                  <br />
                  <div class="form-group">
                    <label for="description">Description:</label>
                    <input type="text" class="form-control" value={description} onChange={e => setDescription(e.target.value)} />
                  </div>
                  <br />
                  <div class="form-group">
                    <label for="baseprice">Base Price:</label>
                    <input type="text" class="form-control" value={baseprice} onChange={e => setBasePrice(e.target.value)} />
                  </div>
                  <br />
                  <div class="form-group">
                    <label for="picon">Product Icon:</label>
                    <input type="file" class="form-control" onChange={handleChange} />
                  </div>
                  <br />
                  <button onClick={handleSubmit} type="button" class="btn btn-danger">Add Product</button>
                  <br /><br />
                </form>

              </div>
            </div>
            <div class="col-md-6">
              <div class="img-box">
                <img src="assets/images/add2.webp" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}
    </>
  );
}

export default Addproducts;
