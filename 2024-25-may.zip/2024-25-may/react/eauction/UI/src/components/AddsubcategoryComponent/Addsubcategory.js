import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { _categoryapiurl, _subcategoryapiurl } from '../../api.url';

function Addsubcategory() {
  const [file, setFile] = useState();
  const [catName, setCatName] = useState();
  const [subCatName, setSubCatName] = useState();
  const [output, setOutput] = useState();
  const [cDetails, setCategoryDetails] = useState([]);

  useEffect(() => {
    axios.get(_categoryapiurl + "fetch").then((response) => {
      setCategoryDetails(response.data);
    }).catch((error) => {
      console.log(error);
    });
  });

  const handleChange = (event) => {
    setFile(event.target.files[0]);
  }
  const handleSubmit = (event) => {
    // alert("check");
    event.preventDefault();
    var formData = new FormData();
    formData.append('catnm', catName);
    formData.append('subcatnm', subCatName);
    formData.append('caticon', file);
    const config = {
      'content-type': 'multipart/form-data'
    };
    axios.post(_subcategoryapiurl + "save", formData, config).then((response) => {
      setCatName("");
      setSubCatName("");
      setOutput(" Sub Category Added Successfully....");
    });
  }


  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="detail-box">
                <div class="heading_container">
                  <h2> Add sub Category</h2>
                </div>
                <form>
                  <font color="blue">{output}</font>
                  <div className="form-group">
                    <label>Category Name</label>
                    <select class="form-control" value={catName} onChange={e => setCatName(e.target.value)}>
                      <option>Select Category</option>
                      {
                        cDetails.map((row) => (
                          <option>{row.catnm}</option>
                        ))
                      }
                    </select>
                  </div>
                  <br />
                  <div class="form-group">
                    <label for="subcatnm">Sub Category Name:</label>
                    <input type="text" class="form-control" value={subCatName} onChange={e => setSubCatName(e.target.value)} />
                  </div>
                  <br />

                  <div className="form-group">
                    <label>Sub Category icon</label>
                    <input
                      type="file"
                      className="form-control"
                      onChange={handleChange} />

                  </div>
                  <button
                    type="button"
                    className="btn"
                    onClick={handleSubmit}>

                    <a href="">Add sub category</a>
                  </button>
                </form>


              </div>
            </div>
            <div class="col-md-6">
              <div class="img-box">
                <img src="assets/images/about-img.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}


    </>
  );
}

export default Addsubcategory;
