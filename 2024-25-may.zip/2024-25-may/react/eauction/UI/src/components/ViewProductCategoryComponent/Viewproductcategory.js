import './Viewproductcategory.css'
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { _categoryapiurl } from '../../api.url';
import { Link } from 'react-router-dom';




function Viewproductcategory() {

  const [cDetails, setCategoryDetails] = useState([]);

  useEffect(() => {
    axios.get(_categoryapiurl + "fetch").then((response) => {
      setCategoryDetails(response.data);
    }).catch((error) => {
      console.log(error);
    });
  });

  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="detail-box">
                <h2 style={{ textAlign: "center" }}>View Product Category</h2>
                <div class="heading_container">
                  <br />
                </div>
              </div>
              <center>
                <div id="category_main">
                  {
                    cDetails.map((row) => (
                      <div class="category_part">
                        <Link to={`/viewpsc/${row.catnm}`}>
                          <img src={`./assets/uploads/caticons/${row.caticonnm}`} height="100" width="150" />
                          <br />
                          <b>{row.catnm}</b>
                        </Link>
                      </div>
                    ))
                  }
                </div>
              </center>
            </div>
            <div class="col-md-6">
              <div class="img-box">
                <img src="assets/images/logo" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}
    </>
  );
}

export default Viewproductcategory;
