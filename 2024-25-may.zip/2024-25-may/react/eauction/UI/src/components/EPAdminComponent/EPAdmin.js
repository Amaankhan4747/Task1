import React from 'react';
import { useState, useEffect } from 'react';
import axios from 'axios';
import { _userapiurl } from '../../api.url';
import { useNavigate } from 'react-router-dom';

function EPAdmin() {
  const navigate = useNavigate();
  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [mobile, setMobile] = useState();
  const [address, setAddress] = useState();
  const [city, setCity] = useState();
  const [gender, setGender] = useState();
  const [M, setM] = useState();
  const [F, setF] = useState();
  const [output, setOutput] = useState();
  useEffect(() => {
    axios.get(_userapiurl + "fatch?email=" + localStorage.getItem("email")).then((Response) => {
      var userDetails = Response.data[0];
      setName(userDetails.name);
      setEmail(userDetails.email);
      setMobile(userDetails.mobile);
      setAddress(userDetails.address);
      setCity(userDetails.city);

      if (userDetails.gender == "male")
        setM("checked");
      else
        setF("checked");
    }).catch((error) => {
      console.log(error);
    });
  }, []);
  const handleSubmit = () => {
    let updateDetails = { "condition_obj": { "email": email }, "content_obj": { "name": name, "mobile": mobile, "address": address, "city": city, "gender": gender } };
    axios.patch(_userapiurl + "update", updateDetails).then((response) => {
      setOutput("Profile edited successfully....");
      navigate("/epadmin");
    });
  };

  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="detail-box">
                <h2> Edit profile user </h2>
                <div class="heading_container">
                  <br />
                  <h2>Register Here !</h2>
                </div>
                <font color="blue">{output}</font>
                <form>

                  <div class="form-group">
                    <label>Full Name</label>
                    <input
                      type="name"
                      class="form-control"
                      placeholder="Enter name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                  <div class="form-group">
                    <label>Email Address</label>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Enter Email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div class="form-group">
                    <label>Moblie</label>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Enter number"
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value)}
                    />
                  </div>
                  <div class="form-group">
                    <label>Address</label>
                    <input
                      type="textarea"
                      class="form-control"
                      placeholder="Enter address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                    />
                  </div>
                  <div class="form-group">
                    <label for="city">City:</label>
                    <select
                      class="form-control"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                    >
                      <option>Select City</option>
                      <optgroup label="MP">
                        <option>Indore</option>
                        <option>Ujjain</option>
                        <option>Bhopal</option>
                      </optgroup>
                      <optgroup label="MH">
                        <option>Mumbai</option>
                        <option>Pune</option>
                        <option>Nasik</option>
                      </optgroup>

                      <optgroup label="RJ">
                        <option>Jaipur</option>
                        <option>udaipur</option>
                        <option>chittorgarh</option>
                      </optgroup>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="gender">Gender:</label>
                    &nbsp;&nbsp; Male{" "}
                    <input
                      type="radio"
                      value="male"
                      checked={M}
                      name="gender"
                      onChange={(e) => setGender(e.target.value)}
                    />
                    &nbsp;&nbsp; Female{" "}
                    <input
                      type="radio"
                      value="female"
                      checked={F}
                      name="gender"
                      onChange={(e) => setGender(e.target.value)}
                    />
                  </div>
                  <br />
                  <button
                    type="button"
                    class="btn btn-primary"
                    onClick={handleSubmit}
                  >
                    Submit
                  </button>
                </form>

              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}


    </>
  );
}

export default EPAdmin