import React from 'react'
import { useState, useEffect } from 'react';
import axios from 'axios';
import { _userapiurl } from '../../api.url';
import { useNavigate } from 'react-router-dom';

function CPAdmin() {

  // const navigate = useNavigate();
  const [opass, setOldpassword] = useState();
  const [npass, setNewpassword] = useState();
  const [cnpass, setConfirmnewpassword] = useState();
  const [output, setOutput] = useState();
  const handleSubmit = () => {
    axios.get(_userapiurl + "fetch?email=" + localStorage.getItem("email") + "&password=" + opass).then((response) => {
      if (npass == cnpass) {
        let updateDetails = { "condition_obj": { "email": localStorage.getItem("email") }, "content_obj": { "password": cnpass } };
        axios.patch(_userapiurl + "update", updateDetails).then((response) => {
          setOutput("Password edited successfully....");
          setOldpassword("");
          setNewpassword("");
          setConfirmnewpassword("");
        });
      }
      else {
        setOutput("New & confirm new password mismatch");
        setNewpassword("");
        setConfirmnewpassword("");
      }
    }).catch((err) => {
      setOutput("Invalid old password");
      setOldpassword("");
    });
  };
  return (
    <>
      {/* about section */}

      <section class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="detail-box">
                <div class="heading_container">
                  <h2>Change Password </h2>
                </div>

                <font color="blue">{output}</font>
                <form>
                  <div class="form-group">
                    <label>Old Password</label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="Enter your old password"
                      value={opass}
                      onChange={(e) => setOldpassword(e.target.value)} />
                  </div>
                  <div class="form-group">
                    <label>New Password</label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="Enter your new password"
                      value={npass}
                      onChange={(e) => setNewpassword(e.target.value)}
                    />
                  </div>
                  <div class="form-group">
                    <label>Confirm new Password</label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="Enter your confirm new password"
                      value={cnpass}
                      onChange={(e) => setConfirmnewpassword(e.target.value)}
                    />
                  </div>

                  <br />
                  <button
                    type="button"
                    class="btn btn-danger"
                    onClick={handleSubmit}>Change</button>
                </form>


              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end about section */}


    </>
  );
}

export default CPAdmin