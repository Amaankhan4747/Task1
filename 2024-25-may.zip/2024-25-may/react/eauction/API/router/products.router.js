import express from 'express';
const UserRouter = express.Router();

import * as ProductsController from '../controller/products.controller.js';

UserRouter.post("/save", ProductsController.save);

UserRouter.get("/fetch", ProductsController.fetch);

// UserRouter.patch("/update", ProductsController.update);

//router.delete("/delete",ProductController.deleteUser);

export default UserRouter;