import express from 'express';
const UserRouter = express.Router();

import * as SubCategoryController from '../controller/SubCategory.controller.js';


UserRouter.post("/save", SubCategoryController.save);


UserRouter.get("/fetch", SubCategoryController.fetch);

// UserRouter.patch("/update", IndexController.update);
// UserRouter.delete("/delete", IndexController.deleteUser);

export default UserRouter;