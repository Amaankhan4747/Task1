import express from 'express';
const UserRouter = express.Router();

import * as CategoryController from '../controller/Category.controller.js';


UserRouter.post("/save", CategoryController.save);
// UserRouter.post("/login", IndexController.login);

UserRouter.get("/fetch", CategoryController.fetch);

// UserRouter.patch("/update", IndexController.update);
// UserRouter.delete("/delete", IndexController.deleteUser);

export default UserRouter;