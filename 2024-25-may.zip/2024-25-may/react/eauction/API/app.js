import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import fileUpload from 'express-fileupload';
const app = express();

// link routers
import UserRouter from "./router/User.router.js";
import CategoryRouter from './router/category.router.js';
import SubCategoryRouter from './router/subcategory.router.js';
import ProductsRouter from './router/products.router.js';

//to extrac file
app.use(fileUpload());
// body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// to allow cors origin request ...

app.use(cors());
// app.use(fileUpload())

// port
app.use("/user", UserRouter);
app.use("/category", CategoryRouter)
app.use("/subcategory", SubCategoryRouter)
app.use("/products", ProductsRouter)
app.listen(3001);
console.log("the server is ready http://localhost:3001");
