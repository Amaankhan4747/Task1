import mongoose from "mongoose";
const url = "mongodb://localhost:27017/newcollection";
// const url = "mongodb://localhost:27017/newcollection";
mongoose.connect(url);
console.log("Successfully connected to mongoDB databased");
