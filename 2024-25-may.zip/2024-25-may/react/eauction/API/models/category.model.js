import mongoose from "mongoose";
import uniqueValidator from 'mongoose-unique-validator';

const CategorySchema = mongoose.Schema({
  _id: Number,
  catnm: {
    type: String,
    required: [true, " category name is required"],
    unique: true,
    trim: true,
  },

  caticonnm: {
    type: String,
    required: [true, "category is required"],
    trim: true,
  },
});

CategorySchema.plugin(uniqueValidator);

const CategorySchemaModel = mongoose.model('Category_Collection', CategorySchema);
export default CategorySchemaModel;