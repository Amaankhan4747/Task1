import mongoose from "mongoose";
import uniqueValidator from 'mongoose-unique-validator';

const ProductsSchema = mongoose.Schema({
  _id: Number,
  title: {
    type: String,
    required: [true, "Title is required"],
    lowercase: true,
    trim: true
  },
  catnm: {
    type: String,
    required: [true, "Category name is required"],
    lowercase: true,
    trim: true
  },
  subcatnm: {
    type: String,
    required: [true, "Sub Category name is required"],
    lowercase: true,
    trim: true
  },
  description: {
    type: String,
    required: [true, "Description is required"],
    lowercase: true,
    trim: true
  },
  baseprice: Number,
  piconnm: {
    type: String,
    required: [true, "Product icon name is required"],
    trim: true
  },
  uid: String,
  info: String
});


ProductsSchema.plugin(uniqueValidator);

const ProductsSchemaModel = mongoose.model('Products_Collection', ProductsSchema);
export default ProductsSchemaModel;