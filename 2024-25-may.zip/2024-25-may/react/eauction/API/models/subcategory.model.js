import mongoose from "mongoose";
import uniqueValidator from 'mongoose-unique-validator';

const SubCategorySchema = mongoose.Schema({
  _id: Number,
  catnm: {
    type: String,
    required: [true, " category name is required"],
    trim: true,
  },

  subcatnm: {
    type: String,
    required: [true, "Sub category is required"],
    trim: true,
  },
  subcaticonnm: {
    type: String,
    required: [true, "Sub Category icon name is required"],
    trim: true
  }
});

SubCategorySchema.plugin(uniqueValidator);

const SubCategorySchemaModel = mongoose.model('SubCategory_Collection', SubCategorySchema);
export default SubCategorySchemaModel;