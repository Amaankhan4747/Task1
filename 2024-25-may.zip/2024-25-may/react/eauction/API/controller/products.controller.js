import '../models/connection.js';
import rs from 'randomstring';
import url from 'url';
import path from 'path';
import ProductsSchemaModel from '../models/products.model.js' // Ensure the path is correct

export var save = async (req, res) => {
  var pList = await ProductsSchemaModel.find();
  var l = pList.length;
  var _id = l == 0 ? 1 : pList[l - 1]._id + 1;

  var picon = req.files.picon;
  var piconnm = rs.generate() + "-" + Date.now() + "-" + picon.name;
  var pDetails = { ...req.body, "piconnm": piconnm, "_id": _id, "info": Date() };

  try {
    await ProductsSchemaModel.create(pDetails);
    var __dirname = url.fileURLToPath(new URL('.', import.meta.url));
    var uploadpath = path.join(__dirname, "../../UI/public/assets/uploads/picons", piconnm);
    picon.mv(uploadpath);
    res.status(201).json({ "status": true });
  }
  catch (error) {
    //console.log(error);
    res.status(500).json({ "status": false });
  }
};

// export var login = async (req, res) => {
//   var condition_obj = { ...req.body, "status": 1 };
//   var UserList = await UserSchemaModel.find(condition_obj);
//   if (UserList.length != 0) {
//     const payload = { "subject": UserList[0].email };
//     const key = rs.generate()
//     const token = jwt.sign(payload, key)
//     res.status(200).json({ "token": token, "UserDetails": UserList[0] });
//   }
//   else res.send(500).json({ "token": "error" });
// };


export var fetch = async (req, res) => {
  var condition_obj = url.parse(req.url, true).query;
  var pList = await ProductsSchemaModel.find(condition_obj);
  if (pList.length != 0)
    res.status(200).json(pList);
  else
    res.status(404).json({ "status": "Resource not found" });
};

/*export var update = async (req, res) => {
  let UserDetails = await UserSchemaModel.findOne(req.body.condition_obj);
  if (UserDetails) {
    let user = await UserSchemaModel.updateOne(req.body.condition_obj, { $set: req.body.content_obj });
    if (user)
      res.status(200).json({ "msg": "success" });
    else
      res.status(500).json({ "status": "Server Error" });
  }
  else
    res.status(404).json({ "status": "Requested resource not available" });
};

export var deleteUser = async (req, res) => {
  let UserDetails = await UserSchemaModel.findOne(req.body);
  if (UserDetails) {
    let user = await UserSchemaModel.deleteOne(req.body);
    if (user)
      res.status(200).json({ "msg": "success" });
    else
      res.status(500).json({ "status": "Server Error" });
  }
  else
    res.status(404).json({ "status": "Requested resource not available" });
};
*/
