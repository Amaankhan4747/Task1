import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import Auth from "../authComponent/Auth";

function Header() {

  const [HeaderContent, setHeaderContent] = useState();
  useEffect(() => {
    if (localStorage.getItem("token") != undefined && localStorage.getItem("role") == "admin") {
      setHeaderContent(<>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="index.html"><Link to="/manageusers" style={{ color: "red" }}>
                  Manageuser
                </Link>
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              {/*----- manage category --*/}

              <li class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="settingsDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  style={{ "color": "#f95c37" }}> Food Management
                </button>
                <div class="dropdown-menu" aria-labelledby="settingsDropdown">
                  <a class="dropdown-item"><Link style={{ "color": "black" }} to="/addcategory">Add Category</Link></a>
                  <a class="dropdown-item"><Link style={{ "color": "black" }} to="/addsubcategory">Add Subcategory list</Link></a>
                </div>
              </li>
              &nbsp; &nbsp;

              <li class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="settingsDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  style={{ "color": "#f95c37" }}>  Manage Food
                </button>
                <div class="dropdown-menu" aria-labelledby="settingsDropdown">
                  <a class="nav-link" href="index.html">
                    <Link to="/addproducts" style={{ color: "red" }}>
                      Add Food</Link>
                  </a>
                  <a class="nav-link" href="index.html">
                    <Link to="/viewpc" style={{ color: "red" }}>
                      Food list
                    </Link>  </a>
                </div>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="">
                  <Link to="/logout" style={{ color: "red" }}>
                    Logout
                  </Link>
                </a>
              </li>
            </ul>
            <form class="form-inline">
              <button
                class="btn  my-2 my-sm-0 nav_search-btn"
                type="submit"
              ></button>
            </form>
          </div>
        </div>

      </>)
    }
    // else if (localStorage.getItem("token") != undefined && localStorage.getItem("role") == "user") {
    //   setHeaderContent(
    //     <>
    //       <div class="collapse navbar-collapse" id="navbarSupportedContent">
    //         <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
    //           <ul class="navbar-nav">

    //             <li class="nav-item">
    //               <a class="nav-link" href="">
    //                 <Link to="/logout" style={{ color: "red" }}>
    //                   Logout
    //                 </Link>
    //               </a>
    //             </li>
    //           </ul>
    //         </div>
    //       </div>

    //     </>
    //   )
    // } 
    else {
      setHeaderContent(<>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="index.html">
                  <Link to="/" style={{ color: "red" }}>
                    Home
                  </Link>
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="">
                  <Link to="/register" style={{ color: "red" }}>
                    Register
                  </Link>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="">
                  <Link to="/login" style={{ color: "red" }}>
                    Login
                  </Link>
                </a>
              </li>
            </ul>
            <form class="form-inline">
              <button
                class="btn  my-2 my-sm-0 nav_search-btn"
                type="submit"
              ></button>
            </form>
          </div>
        </div>
      </>)
    }
  })


  return (
    <>
      <Auth />
      {/* header section strats */}
      <header class="header_section">
        <div class="container">
          <nav class="navbar navbar-expand-lg custom_nav-container pt-3">
            <a class="navbar-brand mr-5" href="index.html">
              <img
                src="assets/images/logom.png"
                alt=""
                style={{ height: "30px", width: "30px" }}
              />
              <span style={{ color: "red" }}>Management tool</span>
            </a>
            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            {HeaderContent}
          </nav>
        </div>
      </header>
      {/* end header section */}
    </>
  );
}

export default Header;
