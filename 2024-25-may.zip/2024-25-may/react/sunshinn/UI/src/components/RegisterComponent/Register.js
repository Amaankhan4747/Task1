import { useState } from "react";
import axios from "axios";
import { _userapiurl } from "../../api.url";

function Register() {
  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [output, setOutput] = useState();

  const handleSubmit = () => {
    const userDetails = {
      name: name,
      email: email,
      password: password,
    };

    axios.post(_userapiurl + "save", userDetails).then((response) => {
      setOutput("Successfully Registered")
      setName("");
      setEmail("");
      setPassword("");
    })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>


      <section class="about_section 
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="detail-box">
                <div class="heading_container">
                  <form>
                    <h2>Register Here !</h2>

                    <div class="form-group">
                      <label>Full Name</label>
                      <input
                        type="name"
                        class="form-control"
                        placeholder="Enter name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </div>
                    <div class="form-group">
                      <label>Email Address</label>
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Enter Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input
                        type="password"
                        class="form-control"
                        placeholder="Enter password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </div>
                    <br />
                    <button
                      type="button"
                      class="btn btn-primary"
                      onClick={handleSubmit}
                    >
                      Submit
                    </button>
                  </form>
                  <p style={{ color: "green" }}>{output}</p>
                </div>
              </div>
            </div>
            <div class="col-md-6"></div>
          </div>
        </div>
      </section>
      {/* end about section */}
    </>
  );
}

export default Register;
