import "./App.css";
import { Routes, Route } from "react-router-dom";
import Header from "./components/HeaderComponent/Header";


import Login from "./components/LoginComponent/Login";
import Register from "./components/RegisterComponent/Register";
import Logout from "./components/LogoutComponent/Logout";
import Manageuser from "./components/ManageuserComponent/Manageuser";
import Addsubcategory from "./components/AddsubcategoryComponent/Addsubcategory";
import Addcategory from "./components/AddcategoryComponent/Addcategory";
import Viewproductcategory from "./components/ViewProductCategoryComponent/Viewproductcategory";
import Viewproductsubcategory from "./components/ViewProductSubCategoryComponent/Viewproductsubcategory";
import Addproducts from "./components/AddproductComponent/Addproducts";
import Viewproducts from "./components/ViewProductsComponent/Viewproducts";
function App() {
  return (
    <>

      <Header />
      <Routes>

        <Route path="/register" element={<Register />}></Route>
        <Route path="/login" element={<Login />}></Route>
        <Route path="/logout" element={<Logout />}></Route>
        <Route path="/manageusers" element={<Manageuser />}></Route>
        <Route path="/addproducts" element={<Addproducts />}></Route>
        <Route path="/addsubcategory" element={<Addsubcategory />}></Route>
        <Route path="/addcategory" element={<Addcategory />}></Route>
        <Route path="/viewpc" element={< Viewproductcategory />}></Route>
        <Route path="/viewp/:subcatnm" element={< Viewproducts />}></Route>
        <Route path="/viewpsc/:catnm" element={< Viewproductsubcategory />}></Route>


      </Routes>

    </>
  );
}

export default App;
